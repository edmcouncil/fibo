# /fnd - FIBO Foundations

## Links

- [JIRA](https://jira.edmcouncil.org/browse/FND)
- [Confluence](https://wiki.edmcouncil.org/display/FND)
