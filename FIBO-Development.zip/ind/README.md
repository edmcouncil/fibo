# /ind - FIBO Indices & Indicators

## Links

- [JIRA](https://jira.edmcouncil.org/browse/IND)
- [Confluence](https://wiki.edmcouncil.org/display/IND)
