# /be - Business Entities

## Links

- [JIRA](https://jira.edmcouncil.org/browse/BE)
- [Confluence](https://wiki.edmcouncil.org/display/BE)
