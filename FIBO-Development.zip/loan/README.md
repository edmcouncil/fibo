# /loan - Loans & Mortgages

## Links

- [JIRA](https://jira.edmcouncil.org/browse/LOAN)
- [Confluence](https://wiki.edmcouncil.org/display/LOAN)

