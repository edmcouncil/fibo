source $(dirname ${0})/build-cats.sh

build1catalog . .

