source $(dirname ${0})/build-about.sh

ontologyCreateAboutFiles 


