sed -i 's/\r//' $1
